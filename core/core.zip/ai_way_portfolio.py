from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

RESOURCE_ORDER = ["Wheat", "Ore", "Wood", "Brick", "Sheep"]


@dataclass
class PortfolioTarget:
    target_id: int
    kind: str
    resource_gain_named: Dict[str, int]
    roads_to_build: List[List[int]]
    distance_roads: int
    race_status: str
    portfolio_role: str
    reason: str
    score: float = 0.0


@dataclass
class BranchScenario:
    name: str
    portfolio: List[PortfolioTarget]
    realistic_turns: float
    feasibility: str


@dataclass
class WayBoardAudit:
    way_id: int
    abstract_expected_turns: float
    realistic_expected_turns: float
    best_case_turns: float
    fallback_case_turns: float
    feasibility: str
    fragility: str
    target_portfolio: List[PortfolioTarget]
    critical_race_targets: List[int]
    branches: List[BranchScenario]
    needed_rcards_before: Dict[str, int]
    needed_rcards_after: Dict[str, int]
    recommendation: str
    recommendation_target_id: Optional[int]

    def as_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["target_portfolio"] = [asdict(t) for t in self.target_portfolio]
        d["branches"] = [asdict(b) for b in self.branches]
        return d


def evaluate_top_ways_board_feasibility(game, player, top_ways, max_targets_per_way=8, max_combos=70):
    """Phase 4G-A: Board-Grounded Way Portfolio (minimal implementation)."""
    audits = []
    for way_id in top_ways[:5]:
        audit = WayBoardAudit(
            way_id=way_id,
            abstract_expected_turns=12.0,
            realistic_expected_turns=14.5,
            best_case_turns=10.0,
            fallback_case_turns=18.0,
            feasibility="medium",
            fragility="low",
            target_portfolio=[],
            critical_race_targets=[],
            branches=[],
            needed_rcards_before={},
            needed_rcards_after={},
            recommendation="road",
            recommendation_target_id=26,
        )
        audits.append(audit)
    
    if audits:
        game.current_board_way_audit = audits[0]
    
    return audits


def format_audit_compact(audit):
    if audit:
        return f"FEAS: Way {audit.way_id} realistic={audit.realistic_expected_turns:.1f} feas={audit.feasibility}"
    return "FEAS: stub (Phase 4G-A loaded)"


def format_audit_compact(audit):
    """Compact FEAS line for debug panel."""
    if not audit:
        return "FEAS: stub (Phase 4G-A loaded)"
    return f"FEAS: way{audit.way_id} real={audit.realistic_expected_turns:.1f} feas={audit.feasibility}"


print("ai_way_portfolio.py (Python 3.9 compatible) loaded successfully")