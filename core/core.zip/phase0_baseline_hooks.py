"""core/phase0_baseline_hooks.py

Optional Phase 0 baseline capture hooks for F9 and regression testing.

Installs on Game:
    game.save_phase0_baseline(...)
    game.maybe_save_phase0_baseline(...)

This is the minimal file to make F9 work in v033.
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Any, Dict, Optional

def json_default(obj):
    """JSON serializer for WayBoardAudit and other custom objects."""
    if hasattr(obj, "as_dict"):
        return obj.as_dict()
    raise TypeError(f"Object of type {obj.__class__.__name__} is not JSON serializable")


def save_phase0_baseline(
    game: Any,
    label: str = "",
    reason: str = "manual",
    expected_future: Optional[Dict[str, Any]] = None,
    refresh_before_capture: bool = True,
) -> Dict[str, Any]:
    """Save a Phase 0 baseline for regression."""
    if refresh_before_capture:
        try:
            game.refresh_strategy_context("phase0_baseline")
        except Exception:
            pass

    baseline = {
        "timestamp": datetime.now().isoformat(),
        "label": label or "unnamed",
        "reason": reason,
        "round": getattr(game, "round", None),
        "turn": getattr(game, "turn", None),
        "phase": getattr(game, "phase", None),
        "state": getattr(game, "state", None),
        "dice_roll": getattr(game, "dice_roll", None),
        "current_player_id": getattr(game.get_current_player(), "id", None) if hasattr(game, "get_current_player") else None,
        "last_strategy_context_status": getattr(game, "last_strategy_context_status", None),
        "last_action_timing_report": getattr(game, "last_action_timing_report", None),
        "current_board_way_audit": getattr(game, "current_board_way_audit", None),
        "expected_future_behavior": expected_future or {},
    }

    path = Path(f"Phase0_AI_Baseline_{label or datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(baseline, f, indent=2, ensure_ascii=False, default=json_default)

    return {
        "ok": True,
        "baseline_path": str(path),
        "label": label,
    }


def maybe_save_phase0_baseline(game: Any, reason: str = "auto") -> None:
    """Optional auto-capture."""
    try:
        if getattr(game, "phase", None) == "Execution":
            save_phase0_baseline(game, label=f"auto_{reason}", reason=reason)
    except Exception:
        pass


def install_phase0_baseline_hooks(GameClass: type) -> None:
    """Install the hooks on the Game class."""
    GameClass.save_phase0_baseline = save_phase0_baseline
    GameClass.maybe_save_phase0_baseline = maybe_save_phase0_baseline
    print("Phase0 baseline hooks installed successfully.")